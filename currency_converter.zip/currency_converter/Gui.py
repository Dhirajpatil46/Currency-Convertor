from tkinter import *
from methodes.main_converter import *
from PIL import Image, ImageTk
DJ_root = Tk()
DJ_root.title("Team Decoder")

DJ_root.geometry("500x400")
DJ_root.minsize(500, 400)
DJ_root.maxsize(500, 400)

image = Image.open("Ac1.jpg")
photo = ImageTk.PhotoImage(image)
L1 = Label(image=photo)
L1.place(x=0, y=0)

T1 = Text(DJ_root, height=1, width=20, bg="#333333", fg="#FFFFBB", borderwidth=3, relief=GROOVE)
T1.place(x=171, y=199)


def inputdata():
    inp = T1.get(1.0, "end-1c")
    if(inp.replace('.', '', 1).isdigit()):
        return inp
    else:
        T2.delete('1.0', END)
        T2.insert(END, "Please Enter Valid Amount!!!")

def d1():

    amount1 = inputdata()
    if(amount1 != None):
        T2.delete('1.0', END)
        T2.insert(END, dollars(amount1))

def e1():
    amount1 = inputdata()
    if(amount1 != None):
        T2.delete('1.0', END)
        T2.insert(END, euro(amount1))


def p1():
    amount1 = inputdata()
    if(amount1 != None):
        T2.delete('1.0', END)
        T2.insert(END, pound(amount1))


def y1():
    amount1 = inputdata()
    if(amount1 != None):
        T2.delete('1.0', END)
        T2.insert(END, yuan(amount1))
    

def r1():
    amount1 = inputdata()
    if(amount1 != None):
        T2.delete('1.0', END)
        T2.insert(END, Rial(amount1))


def a1():
    amount1 = inputdata()
    if(amount1 != None):
        T2.delete('1.0', END)
        T2.insert(END, allin(amount1))
    

L1 = Label(text="!!!...Welcome To Currency Convertor...!!!", bg="#2b2b2b", fg="#e0e0e0", borderwidth=7, relief=RIDGE,font="comicsansms 12 bold")
L1.place(x=100, y=10)

L3 = Label(DJ_root, text="Indian_Rupees", bg="#2b2b2b", fg="#D6D6CF", font="bold")
L3.place(x=190, y=165)

T2 = Text(DJ_root, height=5, width=30, bg="#333333", fg="#FFFFBB", borderwidth=3, relief=GROOVE)
T2.place(x=126, y=270)


Button(text="Dollar", borderwidth=3, relief=SOLID, bg="silver", fg="black", command= d1, font="comicsansms 10 bold").place(x=114, y=227)
Button(text="Euro", borderwidth=3, relief=SOLID, bg="silver", fg="black", command=e1, font="comicsansms 10 bold").place(x=168, y=227)
Button(text="Pound", borderwidth=3, relief=SOLID, bg="silver", fg="black", command=p1, font="comicsansms 10 bold").place(x=213, y=227)
Button(text="Yuan", borderwidth=3, relief=SOLID, bg="silver", fg="black", command=y1, font="comicsansms 10 bold").place(x=269, y=227)
Button(text="Rial", borderwidth=3, relief=SOLID, bg="silver", fg="black", command=r1, font="comicsansms 10 bold").place(x=316, y=227)
Button(text="All", borderwidth=3, relief=SOLID, bg="silver", fg="black", command=a1, font="comicsansms 10 bold").place(x=356, y=227)

DJ_root.mainloop()
