def dollars(dollars):
	d = float(dollars)*0.013
	return "Dollars:- "+str(d)

def euro(euero):
	
	e = float(euro)*0.011
	return "Euro:- "+str(e)

def pound(pound):
	p = float(pound)*0.0097
	return "Pound:- "+str(p)

def yuan(yuan):
	y = float(yuan)*0.087
	return "Yuan:- "+str(y)

def Rial(Rial):
	b = float(Rial)*0.049
	return "Rial:- "+str(b)
 
def allin(allin):
	a = dollars(allin)
	b = euro(allin)
	c = pound(allin)
	d = yuan(allin)
	e = Rial(allin)

	all = a+'\n'+b+'\n'+c+'\n'+d+'\n'+e
	
	return all




 
